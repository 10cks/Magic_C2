#pragma once

char* GetDList(int* pDetermineDataLength);
char* GetScreenshot(int* pDetermineDataLength);