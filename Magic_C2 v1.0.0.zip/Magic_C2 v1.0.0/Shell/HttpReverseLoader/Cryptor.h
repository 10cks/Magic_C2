#pragma once

void EncryptData(char* data, int dataLength);
void DecryptData(char* data, int dataLength);