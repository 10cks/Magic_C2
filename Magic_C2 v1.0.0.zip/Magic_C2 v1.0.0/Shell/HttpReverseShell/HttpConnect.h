#pragma once

string HttpRequest(char* host, int port, char* requestHeader, string sessionData);