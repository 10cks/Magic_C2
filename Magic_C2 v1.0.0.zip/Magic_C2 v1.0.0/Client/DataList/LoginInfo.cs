﻿namespace Client
{
    public class LoginInfo
    {
        public string id { get; set; }
        public string host { get; set; }
        public string port { get; set; }
        public string accessKey { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}