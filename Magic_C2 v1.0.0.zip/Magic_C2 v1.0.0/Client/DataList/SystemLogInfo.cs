﻿namespace Client
{
    public class SystemLogInfo
    {
        public string id { get; set; }
        public string username { get; set; }
        public string content { get; set; }
        public string time { get; set; }
    }
}