﻿namespace Client
{
    public class UserInfo
    {
        public string id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}