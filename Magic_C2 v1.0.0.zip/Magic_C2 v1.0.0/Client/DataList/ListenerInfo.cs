﻿namespace Client
{
    public class ListenerInfo
    {
        public string id { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string description { get; set; }
        public string protocol { get; set; }
        public string port { get; set; }
        public string connectType { get; set; }
    }
}