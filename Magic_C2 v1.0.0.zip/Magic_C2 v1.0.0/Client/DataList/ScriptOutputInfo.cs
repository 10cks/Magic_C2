﻿namespace Client
{
    public class ScriptOutputInfo
    {
        public string display { get; set; }
        public string selfAsm { get; set; }
        public string selfAsmHash { get; set; }
        public string paraHex { get; set; }
        public string scriptInfo { get; set; }
    }
}