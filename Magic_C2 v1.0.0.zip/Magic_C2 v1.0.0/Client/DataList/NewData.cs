﻿namespace Client
{
    public class NewData
    {
        public string dataType { get; set; }
        public string username { get; set; }
        public string content { get; set; }
    }
}